# GitHub Secrets & iOS Codesigning Notes

## Required Secrets (for Android signing)
- KEYSTORE_BASE64: base64 of your ajda3-release-key.jks (use scripts/encode_keystore.sh to generate)
- KEYSTORE_PASSWORD: keystore password
- KEY_PASSWORD: key password
- KEY_ALIAS: key alias (e.g. ajda3_key)

## Optional Secrets (for iOS codesign using certificates)
- IOS_CERT_P12_BASE64: base64 of your p12 certificate for signing
- IOS_CERT_PASSWORD: password for the p12
- MATCH_PASSWORD or APP_STORE_CONNECT_API_KEY (for fastlane / App Store upload)

## How to produce KEYSTORE_BASE64
On macOS / Linux:
```
./scripts/encode_keystore.sh android/app/keystore/ajda3-release-key.jks > keystore.base64
cat keystore.base64 | pbcopy   # macOS - copies to clipboard
```
On Windows (PowerShell):
```
[Convert]::ToBase64String([IO.File]::ReadAllBytes("android\app\keystore\ajda3-release-key.jks")) > keystore.base64
Get-Content keystore.base64 | Set-Clipboard
```

## Adding secrets to GitHub
1. Go to your GitHub repo -> Settings -> Secrets and variables -> Actions -> New repository secret.
2. Add the keys above with values (paste the base64 content for KEYSTORE_BASE64).