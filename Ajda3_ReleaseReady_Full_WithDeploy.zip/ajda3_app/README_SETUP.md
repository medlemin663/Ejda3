Ajda3 - Setup notes (generated)
-------------------------------------------------
This scaffold includes placeholder Firebase files (google-services.json and GoogleService-Info.plist)
located in android/app/ and ios/Runner/ respectively. THESE ARE DUMMY FILES and MUST be replaced
with your project's actual config files for production or real testing.

What I added:
- AndroidManifest.xml with required permissions (android/app/src/main/AndroidManifest.xml)
- ios/Runner/Info.plist with usage descriptions
- Placeholder firebase configs:
    - android/app/google-services.json
    - ios/Runner/GoogleService-Info.plist
- Improved lib/services/user_service.dart to manage user profiles and devices

Quick start:
1. Replace placeholder firebase config files with real ones from Firebase Console.
2. In android/build.gradle and android/app/build.gradle follow Firebase setup (apply plugin: 'com.google.gms.google-services').
3. Run 'flutter pub get' then 'flutter run'.

Security note:
- Do not commit real API keys to public repos.
- Use SHA-1 / SHA-256 for Android OTP on production.

Package name set to: com.medlemin.ajda3
