#!/bin/bash
# generate_keystore.sh
# Usage: ./generate_keystore.sh <keystore-password> <key-password> <alias>
# Example: ./generate_keystore.sh myStorePass myKeyPass ajda3_key

STORE_PASS=${1:-changeit}
KEY_PASS=${2:-changeit}
ALIAS=${3:-ajda3_key}

mkdir -p android/app/keystore
keytool -genkey -v -keystore android/app/keystore/ajda3-release-key.jks \
 -alias ${ALIAS} -keyalg RSA -keysize 2048 -validity 10000 \
 -storepass ${STORE_PASS} -keypass ${KEY_PASS} -dname "CN=Ajda3, OU=Ajda3, O=Ajda3, L=City, ST=State, C=US"

echo "Keystore generated at android/app/keystore/ajda3-release-key.jks"
echo "Please update android/key.properties with the passwords and alias."