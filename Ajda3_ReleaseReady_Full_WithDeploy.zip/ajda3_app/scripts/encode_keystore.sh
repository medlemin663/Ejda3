#!/bin/bash
# encode_keystore.sh - outputs base64 of the keystore to stdout
# Usage: ./encode_keystore.sh android/app/keystore/ajda3-release-key.jks > keystore.base64
FILE=${1:-android/app/keystore/ajda3-release-key.jks}
if [ ! -f "$FILE" ]; then
  echo "File not found: $FILE" >&2
  exit 1
fi
base64 "$FILE"