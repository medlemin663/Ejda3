@echo off
:: generate_keystore.bat
:: Usage: generate_keystore.bat STORE_PASS KEY_PASS ALIAS
set STORE_PASS=%1
set KEY_PASS=%2
set ALIAS=%3
if "%STORE_PASS%"=="" set STORE_PASS=changeit
if "%KEY_PASS%"=="" set KEY_PASS=changeit
if "%ALIAS%"=="" set ALIAS=ajda3_key

if not exist android\app\keystore mkdir android\app\keystore
keytool -genkey -v -keystore android\app\keystore\ajda3-release-key.jks -alias %ALIAS% -keyalg RSA -keysize 2048 -validity 10000 -storepass %STORE_PASS% -keypass %KEY_PASS% -dname "CN=Ajda3, OU=Ajda3, O=Ajda3, L=City, ST=State, C=US"
echo Keystore generated at android\\app\\keystore\\ajda3-release-key.jks
echo Update android\\key.properties with your passwords and alias.