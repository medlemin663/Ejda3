import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'services/local_storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await LocalStorage.init();
  runApp(const Ajda3App());
}

class Ajda3App extends StatefulWidget {
  const Ajda3App({super.key});

  @override
  State<Ajda3App> createState() => _Ajda3AppState();
}

class _Ajda3AppState extends State<Ajda3App> {
  Locale _locale = const Locale('ar');

  void setLocale(Locale locale) {
    setState(() => _locale = locale);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'أجدع',
      debugShowCheckedModeBanner: false,
      locale: _locale,
      supportedLocales: const [Locale('ar'), Locale('fr')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        scaffoldBackgroundColor: Colors.blue[50],
        useMaterial3: false,
      ),
      initialRoute: '/',
      routes: {
        '/': (ctx) => const StartGate(),
        '/login': (ctx) => const LoginScreen(),
        '/home': (ctx) => HomeScreen(onLocaleChange: setLocale),
      },
    );
  }
}

class StartGate extends StatefulWidget {
  const StartGate({super.key});

  @override
  State<StartGate> createState() => _StartGateState();
}

class _StartGateState extends State<StartGate> {
  bool _checking = true;

  @override
  void initState() {
    super.initState();
    _tryAutoLogin();
  }

  Future<void> _tryAutoLogin() async {
    final auto = await LocalStorage.getAutoLoginFlag();
    await Future.delayed(const Duration(milliseconds: 600));
    if (auto) {
      final hasUser = await LocalStorage.hasSavedUser();
      if (hasUser) {
        Navigator.pushReplacementNamed(context, '/home');
      } else {
        Navigator.pushReplacementNamed(context, '/login');
      }
    } else {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: _checking ? const CircularProgressIndicator() : const SizedBox()),
    );
  }
}
