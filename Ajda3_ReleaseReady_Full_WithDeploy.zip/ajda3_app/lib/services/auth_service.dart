import 'package:firebase_auth/firebase_auth.dart';
import 'device_utils.dart';
import 'local_storage.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'user_service.dart';

final FirebaseAuth _auth = FirebaseAuth.instance;

Future<void> startPhoneVerification({
  required String phone,
  required Function(String verificationId) codeSent,
  required Function(UserCredential) onAutoSignIn,
  required Function(String error) onError,
}) async {
  await _auth.verifyPhoneNumber(
    phoneNumber: phone,
    verificationCompleted: (PhoneAuthCredential credential) async {
      try {
        final userCred = await _auth.signInWithCredential(credential);
        final deviceId = await getDeviceId();
        await LocalStorage.saveUser(phone: phone, uid: userCred.user!.uid);
        await UserService.registerDevice(userCred.user!.uid, deviceId);
        onAutoSignIn(userCred);
      } catch (e) {
        onError(e.toString());
      }
    },
    verificationFailed: (FirebaseAuthException e) => onError(e.message ?? e.code),
    codeSent: (verId, token) => codeSent(verId),
    codeAutoRetrievalTimeout: (verId) {},
    timeout: const Duration(seconds: 60),
  );
}

Future<UserCredential> verifySmsCode(String verificationId, String smsCode, String phone) async {
  final credential = PhoneAuthProvider.credential(verificationId: verificationId, smsCode: smsCode);
  final result = await _auth.signInWithCredential(credential);
  final deviceId = await getDeviceId();
  await LocalStorage.saveUser(phone: phone, uid: result.user!.uid);
  await UserService.registerDevice(result.user!.uid, deviceId);
  return result;
}

User? currentUser() => _auth.currentUser;

Future<void> signOut() async {
  await _auth.signOut();
  await LocalStorage.clearAll();
}
