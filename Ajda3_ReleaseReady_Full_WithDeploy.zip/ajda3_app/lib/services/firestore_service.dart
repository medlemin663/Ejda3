import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String> uploadImageFile(File file, String path) async {
    final ref = _storage.ref().child(path);
    final uploadTask = await ref.putFile(file);
    final url = await uploadTask.ref.getDownloadURL();
    return url;
  }

  Future<DocumentReference> addProduct({
    required String name,
    required String weight,
    required String size,
    required List<String> imageUrls,
    required String ownerId,
  }) async {
    final docRef = _db.collection('products').doc();
    await docRef.set({
      'id': docRef.id,
      'name': name,
      'weight': weight,
      'size': size,
      'images': imageUrls,
      'ownerId': ownerId,
      'createdAt': FieldValue.serverTimestamp(),
    });
    return docRef;
  }

  Stream<List<Map<String, dynamic>>> streamUserProducts(String userId) {
    return _db
        .collection('products')
        .where('ownerId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => d.data()).toList());
  }

  Future<void> deleteProduct(String productId) async {
    final doc = _db.collection('products').doc(productId);
    final snapshot = await doc.get();
    if (!snapshot.exists) return;
    final data = snapshot.data();
    if (data != null && data['images'] != null) {
      for (final img in List<String>.from(data['images'])) {
        try {
          await _storage.refFromURL(img).delete();
        } catch (_) {}
      }
    }
    await doc.delete();
  }
}
