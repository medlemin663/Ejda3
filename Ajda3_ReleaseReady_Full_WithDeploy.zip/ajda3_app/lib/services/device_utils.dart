import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';

Future<String> getDeviceId() async {
  final deviceInfo = DeviceInfoPlugin();
  try {
    if (Platform.isAndroid) {
      final info = await deviceInfo.androidInfo;
      return info.id ?? info.androidId ?? '${info.model}_${info.version.sdkInt}';
    } else if (Platform.isIOS) {
      final info = await deviceInfo.iosInfo;
      return info.identifierForVendor ?? info.name ?? info.utsname.machine ?? 'ios-device';
    } else {
      return 'unknown-device';
    }
  } catch (e) {
    return 'unknown-device';
  }
}
