import 'package:shared_preferences/shared_preferences.dart';

class LocalStorage {
  static late SharedPreferences _prefs;
  static const String _kAuto = 'auto_login';
  static const String _kPhone = 'user_phone';
  static const String _kUid = 'user_uid';

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static Future<void> setAutoLogin(bool v) async {
    await _prefs.setBool(_kAuto, v);
  }

  static Future<bool> getAutoLoginFlag() async {
    return _prefs.getBool(_kAuto) ?? false;
  }

  static Future<void> saveUser({required String phone, required String uid}) async {
    await _prefs.setString(_kPhone, phone);
    await _prefs.setString(_kUid, uid);
    await setAutoLogin(true);
  }

  static Future<Map<String, String>?> getSavedUser() async {
    final phone = _prefs.getString(_kPhone);
    final uid = _prefs.getString(_kUid);
    if (phone != null && uid != null) return {'phone': phone, 'uid': uid};
    return null;
  }

  static Future<bool> hasSavedUser() async {
    final user = await getSavedUser();
    return user != null;
  }

  static Future<void> clearAll() async {
    await _prefs.remove(_kPhone);
    await _prefs.remove(_kUid);
    await _prefs.remove(_kAuto);
  }
}
