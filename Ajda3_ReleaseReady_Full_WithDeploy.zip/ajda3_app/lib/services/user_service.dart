import 'package:cloud_firestore/cloud_firestore.dart';

class UserService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Register device (adds deviceId to devices array)
  static Future<void> registerDevice(String uid, String deviceId) async {
    final userRef = _db.collection('users').doc(uid);
    final deviceDoc = {
      'deviceId': deviceId,
      'addedAt': FieldValue.serverTimestamp(),
    };
    await userRef.set({
      'devices': FieldValue.arrayUnion([deviceDoc]),
    }, SetOptions(merge: true));
  }

  static Future<void> removeDevice(String uid, String deviceId) async {
    final userRef = _db.collection('users').doc(uid);
    final doc = await userRef.get();
    if (!doc.exists) return;
    final devices = List.from(doc.data()?['devices'] ?? []);
    devices.removeWhere((d) => d['deviceId'] == deviceId);
    await userRef.update({'devices': devices});
  }

  // Create or update user profile data
  static Future<void> setProfile({
    required String uid,
    required String name,
    required String phone,
    String? email,
    String? avatarUrl,
    String? language,
  }) async {
    final userRef = _db.collection('users').doc(uid);
    final data = {
      'name': name,
      'phone': phone,
      'email': email ?? FieldValue.delete(),
      'avatarUrl': avatarUrl ?? FieldValue.delete(),
      'language': language ?? 'ar',
      'updatedAt': FieldValue.serverTimestamp(),
    };
    await userRef.set(data, SetOptions(merge: true));
  }

  // Get user profile
  static Future<Map<String, dynamic>?> getProfile(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists) return null;
    return doc.data();
  }

  // Stream profile for realtime updates
  static Stream<DocumentSnapshot> streamProfile(String uid) {
    return _db.collection('users').doc(uid).snapshots();
  }
}
