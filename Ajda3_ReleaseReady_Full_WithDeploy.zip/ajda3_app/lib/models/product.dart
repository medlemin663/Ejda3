class Product {
  final String id;
  final String name;
  final String weight;
  final String size;
  final List<String> images;
  final String ownerId;
  Product({
    required this.id,
    required this.name,
    required this.weight,
    required this.size,
    required this.images,
    required this.ownerId,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'weight': weight,
        'size': size,
        'images': images,
        'ownerId': ownerId,
        'createdAt': DateTime.now().toUtc(),
      };

  factory Product.fromMap(Map<String, dynamic> m) => Product(
        id: m['id'] ?? '',
        name: m['name'] ?? '',
        weight: m['weight'] ?? '',
        size: m['size'] ?? '',
        images: List<String>.from(m['images'] ?? []),
        ownerId: m['ownerId'] ?? '',
      );
}
