import 'package:flutter/material.dart';
import 'package:sms_autofill/sms_autofill.dart';
import '../services/auth_service.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _phoneCtrl = TextEditingController(text: '+222');
  bool _sending = false;
  String _verificationId = '';

  void _sendOtp() async {
    final phone = _phoneCtrl.text.trim();
    if (phone.isEmpty) return;
    setState(() => _sending = true);
    await startPhoneVerification(
      phone: phone,
      codeSent: (verId) {
        setState(() {
          _verificationId = verId;
          _sending = false;
        });
        Navigator.push(context, MaterialPageRoute(builder: (_) => OTPScreen(phone: phone, verificationId: verId)));
      },
      onAutoSignIn: (userCred) {
        Navigator.pushReplacementNamed(context, '/home');
      },
      onError: (err) {
        setState(() => _sending = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
      },
    );
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل / تسجيل دخول'), backgroundColor: Colors.lightBlue),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 20),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'رقم الهاتف (مع رمز الدولة)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.lightBlue),
              onPressed: _sending ? null : _sendOtp,
              child: _sending ? const CircularProgressIndicator(color: Colors.white) : const Text('إرسال OTP'),
            ),
            const SizedBox(height: 8),
            TextButton(onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('استخدم OTP لإعادة التعيين')));
            }, child: const Text('نسيت كلمة السر؟')),
          ],
        ),
      ),
    );
  }
}
