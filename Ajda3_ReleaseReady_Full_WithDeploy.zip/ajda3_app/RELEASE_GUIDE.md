# RELEASE_GUIDE - Ajda3 (أجدع)
هذا الدليل يشرح بالخطوات كيفية توليد keystore، إعداد GitHub Actions، وبناء ونشر التطبيق على Google Play وApp Store.

## A. توليد keystore محلياً (موصى به، لا ترفع المفتاح للمستودع العام)
على جهازك نفّذ:
```
keytool -genkey -v -keystore ajda3-release-key.jks -alias ajda3_key -keyalg RSA -keysize 2048 -validity 10000
```
- انسخ الناتج إلى `android/app/keystore/ajda3-release-key.jks` في المشروع (أو احتفظ به في مكان آمن).
- عدّل `android/key.properties` أو انسخ `android/key.properties.sample` واملأ القيم الحقيقية.

## B. إضافة الأسرار في GitHub (Repository Settings → Secrets)
- KEYSTORE_BASE64 : محتوى ملف `.jks` مشفّر base64:
  - على جهازك: `base64 ajda3-release-key.jks | pbcopy` (macOS) أو `base64 ajda3-release-key.jks` ثم انسخ
- KEYSTORE_PASSWORD : كلمة مرور keystore
- KEY_PASSWORD : كلمة المرور للمفتاح
- KEY_ALIAS : اسم alias (مثال: ajda3_key)

## C. تفعيل GitHub Actions
- تم تضمين ملف workflow: `.github/workflows/flutter-ci.yml`
- عند كل دفع (push) لفرع `main` أو `master` سيبني GitHub AAB وينشره كأرتيفكت

## D. بناء محلي (بدون CI)
### Android AAB
```
flutter pub get
flutter build appbundle --release
```
### Android APK (للاختبار)
```
flutter build apk --release
```

## E. خطوات رفع Google Play
1. سجل حساب مطور Google Play (مرة واحدة).
2. افتح Play Console وأنشئ تطبيق جديد.
3. في قسم Release → Production → Create Release، حمّل `app-release.aab` الناتج.
4. أكمل بيانات التطبيق (صور، وصف، سياسة الخصوصية، فئات).
5. اختبر وقم بالإرسال للمراجعة.

## F. خطوات رفع App Store (iOS)
- تحتاج macOS وApple Developer Account.
- افتح Xcode، اضبط Bundle ID: `com.medlemin.ajda3`, أدخل `GoogleService-Info.plist`.
- Archive ثم Upload to App Store Connect.
- أكمل بيانات التطبيق في App Store Connect ثم أرسل للمراجعة.

## G. ملاحظات أمان
- لا ترفع keystore أو key.properties الحقيقي إلى Git.
- استخدم GitHub Secrets لحفظ القيم الحسّاسة.
- في بيئة التطوير استخدم أرقام اختبار Firebase لتجنب مشكلات SMS.

## CI Deploy

Added GitHub Actions job `deploy-to-playstore` which uses Fastlane. Provide `PLAYSTORE_JSON_BASE64` secret (base64 of service account JSON) in GitHub Secrets.

For iOS deployment via CI you need to provide signing certificates and provisioning profiles and set up fastlane match or App Store Connect API key as secrets.
