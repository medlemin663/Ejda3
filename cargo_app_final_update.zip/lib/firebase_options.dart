// Replace this file by running `flutterfire configure` which generates platform-specific Firebase options.
// This placeholder prevents import errors during initial development.
class DefaultFirebaseOptions {
  static get currentPlatform => null;
}
