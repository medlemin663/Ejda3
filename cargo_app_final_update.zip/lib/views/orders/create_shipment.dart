// lib/views/orders/create_shipment.dart
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart';
import '../../services/storage_service.dart';
import '../../models/shipment_provider.dart';
import '../maps/map_picker_screen.dart';

const Color kPrimarySkyBlue = Color(0xFF00B0FF);
const int kMaxImages = 5;

class CreateShipmentModernScreen extends StatefulWidget {
  const CreateShipmentModernScreen({super.key});

  @override
  State<CreateShipmentModernScreen> createState() => _CreateShipmentModernScreenState();
}

class _CreateShipmentModernScreenState extends State<CreateShipmentModernScreen> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final StorageService _storageService = StorageService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // sender
  String senderName = '';
  String senderPhone = '';
  String senderCity = '';

  // receiver
  String receiverName = '';
  String receiverPhone = '';
  String receiverCity = '';

  // details
  String packageType = 'وثائق';
  final List<String> packageTypes = ['وثائق', 'إلكترونيات', 'طعام', 'أخرى'];
  double weight = 0.0;
  String notes = '';

  // images
  final List<XFile> _pickedImages = [];
  final List<String> _uploadedUrls = [];
  bool _isUploading = false;
  double _uploadProgress = 0.0;

  // locations
  String pickupLocationText = 'انقر لاختيار موقع الاستلام';
  String deliveryLocationText = 'انقر لاختيار موقع التسليم';
  Map<String, dynamic>? pickupLocation; // {lat, lng, address}
  Map<String, dynamic>? deliveryLocation;

  final ImagePicker _picker = ImagePicker();

  // animation controller for submit button
  late AnimationController _btnController;
  late Animation<double> _btnScale;

  @override
  void initState() {
    super.initState();
    _btnController = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _btnScale = Tween<double>(begin: 1.0, end: 0.96).animate(CurvedAnimation(parent: _btnController, curve: Curves.easeOut));
    _determinePositionAndSetPickup();
  }

  @override
  void dispose() {
    _btnController.dispose();
    super.dispose();
  }

  Future<void> _determinePositionAndSetPickup() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return;
    }

    final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    setState(() {
      pickupLocation = {'lat': pos.latitude, 'lng': pos.longitude, 'address': 'موقعي الحالي'};
      pickupLocationText = 'موقعي الحالي';
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? file = await _picker.pickImage(source: source, imageQuality: 80);
      if (file != null) {
        if (_pickedImages.length >= kMaxImages) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('يمكن رفع حتى \$kMaxImages صور فقط')),
          );
          return;
        }
        setState(() => _pickedImages.add(file));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ في اختيار الصورة: \$e')));
    }
  }

  void _removePickedImage(int index) {
    setState(() {
      _pickedImages.removeAt(index);
    });
  }

  Future<void> _pickLocation(bool isPickup) async {
    final result = await Navigator.push<Map<String, dynamic>?>(
      context,
      MaterialPageRoute(builder: (_) => const MapPickerScreen()),
    );
    if (result != null) {
      setState(() {
        if (isPickup) {
          pickupLocation = result;
          pickupLocationText = result['address'] ?? '${result['lat']}, ${result['lng']}';
        } else {
          deliveryLocation = result;
          deliveryLocationText = result['address'] ?? '${result['lat']}, ${result['lng']}';
        }
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم اختيار الموقع')));
    }
  }

  Future<List<String>> _uploadAllImages(String shipmentId) async {
    _uploadedUrls.clear();
    if (_pickedImages.isEmpty) return _uploadedUrls;

    setState(() {
      _isUploading = true;
      _uploadProgress = 0.0;
    });

    final total = _pickedImages.length;
    int done = 0;

    for (final xfile in _pickedImages) {
      final file = File(xfile.path);
      try {
        final url = await _storageService.uploadFile(shipmentId, file, 'image');
        _uploadedUrls.add(url);
      } catch (e) {
        debugPrint('Upload failed for \${xfile.path}: \$e');
      }
      done++;
      setState(() {
        _uploadProgress = done / total;
      });
    }

    setState(() {
      _isUploading = false;
    });

    return _uploadedUrls;
  }

  Future<void> _saveShipment() async {
    if (!_formKey.currentState!.validate()) return;
    if (pickupLocation == null || deliveryLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء تحديد موقعي الاستلام والتسليم')));
      return;
    }
    _formKey.currentState!.save();

    final docRef = _firestore.collection('shipments').doc();
    final shipmentId = docRef.id;

    try {
      await _uploadAllImages(shipmentId);

      final data = {
        'id': shipmentId,
        'sender': {
          'name': senderName,
          'phone': senderPhone,
          'city': senderCity,
        },
        'receiver': {
          'name': receiverName,
          'phone': receiverPhone,
          'city': receiverCity,
        },
        'details': {
          'packageType': packageType,
          'weight': weight,
          'notes': notes,
          'attachments': _uploadedUrls,
        },
        'pickupLocation': pickupLocation,
        'deliveryLocation': deliveryLocation,
        'status': 'Pending',
        'createdAt': FieldValue.serverTimestamp(),
      };

      await docRef.set(data);

      Provider.of<ShipmentProvider>(context, listen: false).addLocalShipment({
        'id': shipmentId,
        'status': 'Pending',
        'description': data['details']['packageType'] + ' - ' + (data['details']['weight']?.toString() ?? ''),
      });

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('✅ تم إنشاء الشحنة بنجاح')));

      _formKey.currentState!.reset();
      setState(() {
        _pickedImages.clear();
        _uploadedUrls.clear();
        // keep pickup as user's current unless user changed it
        deliveryLocation = null;
        deliveryLocationText = 'انقر لاختيار موقع التسليم';
        packageType = packageTypes.first;
        weight = 0.0;
      });

      Navigator.of(context).pop(true);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل إنشاء الشحنة: \$e')));
    }
  }

  Widget _buildImagesPreview() {
    if (_pickedImages.isEmpty) {
      return const SizedBox.shrink();
    }
    return SizedBox(
      height: 96,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _pickedImages.length,
        itemBuilder: (context, index) {
          final img = _pickedImages[index];
          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Stack(
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOut,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), boxShadow: [
                    BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3))
                  ]),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(File(img.path), width: 96, height: 96, fit: BoxFit.cover),
                  ),
                ),
                Positioned(
                  top: 4,
                  right: 4,
                  child: InkWell(
                    onTap: () => _removePickedImage(index),
                    child: Container(
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black54),
                      child: const Padding(
                        padding: EdgeInsets.all(4.0),
                        child: Icon(Icons.close, size: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSubmitButton() {
    return ScaleTransition(
      scale: _btnScale,
      child: GestureDetector(
        onTapDown: (_) => _btnController.forward(),
        onTapUp: (_) => _btnController.reverse(),
        onTapCancel: () => _btnController.reverse(),
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: kPrimarySkyBlue,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: _isUploading ? null : _saveShipment,
            child: _isUploading
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(width: 8),
                      const CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      const SizedBox(width: 12),
                      Text('جارٍ رفع الصور... \${(_uploadProgress * 100).toStringAsFixed(0)}%'),
                    ],
                  )
                : const Text('إرسال الشحنة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cardRadius = BorderRadius.circular(14.0);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kPrimarySkyBlue,
        title: const Text('تسجيل شحنة جديدة'),
        elevation: 0,
      ),
      backgroundColor: Colors.grey[100],
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Card(
                shape: RoundedRectangleBorder(borderRadius: cardRadius),
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text('معلومات المرسل', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        TextFormField(
                          decoration: const InputDecoration(prefixIcon: Icon(Icons.person), hintText: 'الاسم الكامل'),
                          validator: (v) => v == null || v.isEmpty ? 'الرجاء إدخال اسم المرسل' : null,
                          onSaved: (v) => senderName = v!.trim(),
                        ),
                        const SizedBox(height: 8),
                        TextFormField(
                          decoration: const InputDecoration(prefixIcon: Icon(Icons.phone), hintText: 'رقم الهاتف'),
                          keyboardType: TextInputType.phone,
                          validator: (v) => v == null || v.isEmpty ? 'الرجاء إدخال رقم الهاتف' : null,
                          onSaved: (v) => senderPhone = v!.trim(),
                        ),
                        const SizedBox(height: 8),
                        TextFormField(
                          decoration: const InputDecoration(prefixIcon: Icon(Icons.location_city), hintText: 'المدينة'),
                          validator: (v) => v == null || v.isEmpty ? 'الرجاء إدخال المدينة' : null,
                          onSaved: (v) => senderCity = v!.trim(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                shape: RoundedRectangleBorder(borderRadius: cardRadius),
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Text('معلومات المستلم', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    TextFormField(
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.person_outline), hintText: 'اسم المستلم'),
                      validator: (v) => v == null || v.isEmpty ? 'الرجاء إدخال اسم المستلم' : null,
                      onSaved: (v) => receiverName = v!.trim(),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.phone_android), hintText: 'رقم المستلم'),
                      keyboardType: TextInputType.phone,
                      validator: (v) => v == null || v.isEmpty ? 'الرجاء إدخال رقم المستلم' : null,
                      onSaved: (v) => receiverPhone = v!.trim(),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.location_city), hintText: 'مدينة التسليم'),
                      validator: (v) => v == null || v.isEmpty ? 'الرجاء إدخال المدينة' : null,
                      onSaved: (v) => receiverCity = v!.trim(),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                shape: RoundedRectangleBorder(borderRadius: cardRadius),
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Text('تفاصيل الشحنة', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: packageType,
                      items: packageTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.category)),
                      onChanged: (v) => setState(() => packageType = v ?? packageType),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.line_weight), hintText: 'الوزن (كجم)'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'الرجاء إدخال الوزن';
                        final d = double.tryParse(v);
                        if (d == null || d <= 0) return 'أدخل وزنًا صحيحًا';
                        return null;
                      },
                      onSaved: (v) => weight = double.parse(v!.trim()),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.note), hintText: 'ملاحظات إضافية (اختياري)'),
                      maxLines: 2,
                      onSaved: (v) => notes = v?.trim() ?? '',
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                shape: RoundedRectangleBorder(borderRadius: cardRadius),
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Text('صور البضاعة', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(backgroundColor: kPrimarySkyBlue),
                          onPressed: () => _pickImage(ImageSource.camera),
                          icon: const Icon(Icons.camera_alt),
                          label: const Text('كاميرا'),
                        ),
                        const SizedBox(width: 10),
                        OutlinedButton.icon(
                          onPressed: () => _pickImage(ImageSource.gallery),
                          icon: const Icon(Icons.photo_library),
                          label: const Text('المعرض'),
                        ),
                        const SizedBox(width: 10),
                        Text('(\${_pickedImages.length}/\$kMaxImages)', style: const TextStyle(color: Colors.grey)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    _buildImagesPreview(),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                shape: RoundedRectangleBorder(borderRadius: cardRadius),
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Text('الموقع الجغرافي', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    ListTile(
                      onTap: () => _pickLocation(true),
                      title: Text(pickupLocationText),
                      leading: const Icon(Icons.my_location),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    ),
                    const Divider(),
                    ListTile(
                      onTap: () => _pickLocation(false),
                      title: Text(deliveryLocationText),
                      leading: const Icon(Icons.place),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    ),
                    const SizedBox(height: 6),
                    const Text('ملاحظة: اضغط على الخريطة لاختيار الموقع بدقة.', style: TextStyle(fontSize: 12, color: Colors.grey)),
                  ]),
                ),
              ),
              const SizedBox(height: 18),
              _buildSubmitButton(),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
