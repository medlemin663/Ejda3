import 'package:flutter/material.dart';
import '../orders/orders_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const OrdersScreen();
  }
}
