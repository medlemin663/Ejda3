import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../orders/orders_screen.dart';
import 'package:google_fonts/google_fonts.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _loading = false;

  Future<void> _signInAnonymously() async {
    setState(() => _loading = true);
    try {
      await FirebaseAuth.instance.signInAnonymously();
      // on success, navigate to OrdersScreen (AppEntryPoint splash handles session too)
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const OrdersScreen()));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل تسجيل الدخول: \$e')));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.symmetric(horizontal: 24), child: Column(
        children: [
          const SizedBox(height: 30),
          Hero(tag: 'logo', child: Icon(Icons.local_shipping, size: 90, color: Colors.cyan)),
          const SizedBox(height: 18),
          Text('Cargo Delivery', style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 30),
          const Text('تجربة تسجيل دخول سريعة (ديمو). سيتم الاحتفاظ بجلسة المستخدم تلقائياً.', textAlign: TextAlign.center),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _loading ? null : _signInAnonymously, child: _loading ? const CircularProgressIndicator(color: Colors.white) : const Padding(padding: EdgeInsets.symmetric(vertical:12), child: Text('تسجيل الدخول التلقائي')))),
          const SizedBox(height: 12),
          TextButton(onPressed: () {}, child: const Text('إنشاء حساب/تسجيل بالبريد (مستقبلاً)')),
        ],
      ),),),),
    );
  }
}
